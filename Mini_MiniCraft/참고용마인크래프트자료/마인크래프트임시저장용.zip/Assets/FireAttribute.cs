﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireAttribute : BaseBlockAttribute 
{

	BlockCom m_LinkBlockCom = null;
	void Awake()
	{
		m_LinkBlockCom = this.GetComponent<BlockCom>();

	}

	void SendEvent( int p_x, int p_y, int p_z )
	{
		Debug.LogFormat( "SendEvent : {0}, {1}, {2} ", p_x, p_y, p_z );
		BlockCom linkblock = MapGenerator.GetI.GetGridIndexBlockCom(p_x, p_y, p_z);
		if( linkblock != null )
			linkblock.SetFireEvent();
	}

	void StartEvent()
	{
		Vector3Int gridindex = Vector3Int.RoundToInt( m_LinkBlockCom.transform.position );
		Debug.LogFormat( "StartEvent : {0} ", gridindex );

		// 6방향이벤트 날리기
		m_LinkBlockCom.SetBlockType( E_BlockType.Soil );
		
		// 위, 아래
		SendEvent(gridindex.x, gridindex.y + 1, gridindex.z);
		SendEvent(gridindex.x, gridindex.y - 1, gridindex.z);
		// 우, 좌
		SendEvent(gridindex.x + 1, gridindex.y, gridindex.z);
		SendEvent(gridindex.x - 1, gridindex.y, gridindex.z);
		// 앞, 뒤
		SendEvent(gridindex.x, gridindex.y, gridindex.z + 1);
		SendEvent(gridindex.x, gridindex.y, gridindex.z - 1);


		//this.Invoke("EndEvent", 0.5f);
		EndEvent();
	}

	void EndEvent()
	{

		GameObject.Destroy( this );
	}

	void Start () 
	{
		this.Invoke( "StartEvent", 0.5f );
		
	}

	
	void Update () 
	{
		
	}
}
