﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class BlockManager : Singleton<BlockManager> 
{

	public BlockCom[] BlockComArray;



	public BlockCom GetBlockType(E_BlockType p_blocktype )
	{

		return BlockComArray[(int)p_blocktype];
	}

	public Material GetMaterialBlockType( E_BlockType p_blocktype )
	{
		// BlockCom tempcom = BlockComArray[(int)p_blocktype];
		// if( tempcom != null )
		// {
		// 	MeshRenderer render = tempcom.GetComponent<MeshRenderer>();
		// 	if( render != null )
		// 	{
		// 		return render.material;
		// 	}
		// }

		return BlockComArray[(int)p_blocktype].GetComponent<MeshRenderer>().material;
	}


	void Start () 
	{

	}
	
	void Update () 
	{
		
	}
}
