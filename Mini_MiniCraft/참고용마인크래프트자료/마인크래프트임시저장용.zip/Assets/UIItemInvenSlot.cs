﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;


public enum E_SlotType
{
	E_InvenSlot = 0,
	E_SmithSlot,
	E_DockSlot,

	Max,
}


public class UIItemInvenSlot : MonoBehaviour
, IBaseSlot 
, IPointerUpHandler
{
	public E_ItemType CurrentItemType = E_ItemType.Max;
	public Image CurrentImage = null;
	public Text CountLabel = null;

	public Image CountBGImage = null;


	UIItemDragSlot m_DragSlotImage = null;

	public E_ItemType GetItemType()
	{
		return CurrentItemType;
	}
	public E_SlotType SlotType
	{
		get { return E_SlotType.E_InvenSlot; }
	}


	public void _On_DragEvent( BaseEventData p_event )
	{
		PointerEventData pointerevent = p_event as PointerEventData;
		if( m_DragSlotImage != null )
		{
			//RectTransformUtility.CalculateRelativeRectTransformBounds()
			m_DragSlotImage.GetComponent<RectTransform>().anchoredPosition = pointerevent.position;
		}
	}

	public void OnPointerUp(PointerEventData eventData)
	{
		if( m_DragSlotImage != null)
		{
			m_DragSlotImage.gameObject.SetActive(false);
			m_DragSlotImage = null;
		}
	}

	public void _On_BeginDrag( BaseEventData p_event )
	{
		PointerEventData pointerevent = p_event as PointerEventData;
		Debug.Log("Inven BeginDrag : " + this.name );

		if( this.CurrentItemType == E_ItemType.Max
			|| this.CurrentItemType == E_ItemType.None )
		{
			return;
		}

		m_DragSlotImage = UIManager.Instance.GetDragSlotImage();
		m_DragSlotImage.gameObject.SetActive(true);
		m_DragSlotImage.SetChangeSlotIcon( CurrentImage.sprite );


	}

	public void _On_DropEvent( BaseEventData p_event )
	{

		PointerEventData pointerevent = p_event as PointerEventData;
		Debug.Log( this.name + " : Drop : " + pointerevent.pointerPress.name );


		E_ItemType srctype = CurrentItemType;
		IBaseSlot destslot = 
					pointerevent.pointerPress.GetComponent<IBaseSlot>();
		E_ItemType desttype = destslot.GetItemType();


		if( destslot.SlotType == E_SlotType.E_InvenSlot )
		{
			// swap
			destslot.SetItemType( srctype );
			this.SetItemType( desttype );
		}
		else
		{
			destslot.SetItemType( E_ItemType.None );
		}
		


		if( m_DragSlotImage != null)
		{
			m_DragSlotImage.gameObject.SetActive(false);
			m_DragSlotImage = null;
		}
	}


	public void UpdateItemData()
	{
		if( CurrentItemType == E_ItemType.None 
		|| CurrentItemType == E_ItemType.Max )
		{
			CountBGImage.gameObject.SetActive(false);
			CountLabel.gameObject.SetActive(false);
			return;
		}


		CountBGImage.gameObject.SetActive(true);
		CountLabel.gameObject.SetActive(true);
		UserItemData itemdata = UserItemManager.Instance.GetItemData( CurrentItemType );
		if(itemdata == null)
		{
			CurrentItemType = E_ItemType.None;
			CountBGImage.gameObject.SetActive(false);
			CountLabel.gameObject.SetActive(false);
			CurrentImage.color = new Color(1f, 1f, 1f, 0f );
		}
		else
		{
			CountLabel.text = itemdata.TotalCount.ToString();
			CurrentImage.color = new Color(1f, 1f, 1f, 1f );
		}

	}

	public void SetItemType( E_ItemType p_itemtype )
	{
		if( CurrentImage == null )
		{
			CurrentImage = this.GetComponent<Image>();
		}

		CurrentItemType = p_itemtype;

		ItemData data = ItemManager.Instance.GetItemData( CurrentItemType );

		if( data != null
		 && data.ItemType != E_ItemType.None
		 && data.ItemType != E_ItemType.Max
		  )
		{
			CurrentImage.sprite = data.ItemSprite;
			CurrentImage.color = new Color(1f, 1f, 1f, 1f );
		}
		else
		{
			CurrentImage.sprite = null;
			CurrentImage.color = new Color(1f, 1f, 1f, 0f );
		}
		

		UpdateItemData();
	}

	void Start () 
	{
		SetItemType( CurrentItemType );
	}
	
	void Update () 
	{
		
	}
}
