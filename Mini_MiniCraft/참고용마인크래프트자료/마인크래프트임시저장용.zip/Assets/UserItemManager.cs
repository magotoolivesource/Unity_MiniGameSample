﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 작업 진행목록
// 대장간, 하단에 는 드롭하면 복사하기
// 대장간내에서는 드롭하면 서로간 반환하기
// 인벤들간 이동하면 스왑하기
// 대장간에서 인벤으로 이동시키면 대장간부분만 지우도록 하기
// 대장간에서 인벤 범위 벗어나면 그냥 지우도록 하기
// 대장간 사용후 인벤에 사용되는 아이템들 지우도록 하기
// 인벤창 닫으면 아이템들 다 돌려놓기


// 아이템카운팅적용하기
// 블럭 아이템 생성하기
// 나무들 심기



[System.Serializable]
public class UserItemData
{
	public UserItemData()
	{
		
	}
	public UserItemData( E_ItemType p_itemtype, int p_count )
	{
		CurrentItemType = p_itemtype;
		TotalCount = p_count;
	}


	public int TotalCount = 0;
	public E_ItemType CurrentItemType = E_ItemType.Max;

	//public int InvenSlotIndex = -1;

}


public class UserItemManager : Singleton<UserItemManager> 
{
	public List<UserItemData> TotalItemData = new List<UserItemData>();


	void TestUserItem()
	{

	// 	Stone,
	// Wood,
	// Iron,

	// StonePick, // 
	// IronPick,
	// IronAxe,
	// Scythe,

		UserItemData itemdata = new UserItemData();
		itemdata.CurrentItemType = E_ItemType.Stone;
		itemdata.TotalCount = 100;
		TotalItemData.Add( itemdata );
		itemdata = new UserItemData( E_ItemType.Wood, 100 );
		TotalItemData.Add( itemdata );
		itemdata = new UserItemData(){CurrentItemType = E_ItemType.Iron, TotalCount = 5 };
		TotalItemData.Add( itemdata );


		// 블럭 데이터
		itemdata = new UserItemData(){CurrentItemType = E_ItemType.Soil, TotalCount = 210 };
		TotalItemData.Add( itemdata );
		// itemdata = new UserItemData(){CurrentItemType = E_ItemType.Grass, TotalCount = 220 };
		// TotalItemData.Add( itemdata );
		itemdata = new UserItemData(){CurrentItemType = E_ItemType.Desert, TotalCount = 230 };
		TotalItemData.Add( itemdata );
		itemdata = new UserItemData(){CurrentItemType = E_ItemType.Gold, TotalCount = 240 };
		TotalItemData.Add( itemdata );

		itemdata = new UserItemData(){CurrentItemType = E_ItemType.StonePick, TotalCount = 1 };
		TotalItemData.Add( itemdata );
		

		itemdata = new UserItemData(){CurrentItemType = E_ItemType.Carrot, TotalCount = 20 };
		TotalItemData.Add( itemdata );

	}


	public UserItemData GetItemData( E_ItemType p_itemtype )
	{
		foreach( UserItemData elementdata in TotalItemData )
		{
			if( elementdata.CurrentItemType == p_itemtype )
			{
				return elementdata;
			}
		}

		return null;
	}

	public bool AddItem( E_ItemType p_itemtype, int p_addcount )
	{
		if( p_itemtype == E_ItemType.None
			|| p_itemtype == E_ItemType.Max )
		{
			return false;
		}


		bool addflag = false;
		UserItemData itemdata = GetItemData( p_itemtype );
		if( itemdata == null)
		{
			itemdata = new UserItemData(p_itemtype, 0);
			TotalItemData.Add( itemdata );
			addflag = true;
		}

		itemdata.TotalCount += p_addcount;
		return addflag;
	}

	public void RemoveItem( E_ItemType p_itemtype, int p_removecount )
	{
		if( p_itemtype == E_ItemType.None
			|| p_itemtype == E_ItemType.Max )
		{
			return;
		}


		UserItemData itemdata = GetItemData( p_itemtype );
		if( itemdata == null)
		{
			return;
		}


		itemdata.TotalCount -= p_removecount;
		if( itemdata.TotalCount <= 0 )
		{
			TotalItemData.Remove( itemdata );
		}

	}


	public void DestryBlock( BlockCom p_block )
	{
		if(p_block.CurrentBlockType == E_BlockType.Max )
		{
			return;
		}
		

		E_ItemType itemtype = ItemManager.Instance.GetBlockTypeTOItem( p_block.CurrentBlockType );
		bool isadd = AddItem( itemtype, p_block.ResultCount );

		if( isadd )
		{
			// 빈슬롯에 아이템UI 추가
			UIManager.Instance.UIItemInvenCom.UIAddEmptySlot( itemtype );
		}
		else
		{
			// 유지상태에서 카운팅만적용
			UIManager.Instance.UIReflashAllDatas();


			// 재정렬
			//UIManager.Instance.UIItemInvenCom.UIReflashUserItemDatas();
		}

		

	}



	void Awake() 
	{
		TestUserItem();


	}

	void Start () 
	{

	}
	
	void Update () 
	{
		
	}
}
