﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public enum E_BlockType
{
	Soil = 0,
	Grass,
	Desert,
	Ice,

	Mine,
	Iron,
	Gold,


	Carrot,

	Max
}



public class MapGenerator : MonoBehaviour 
{
	// 싱글톤 ---------------
	private static MapGenerator m_Instance = null;
	public static MapGenerator GetI
	{
		get
		{
			if( m_Instance == null )
			{
				m_Instance = GameObject.FindObjectOfType<MapGenerator>();
			}
			return m_Instance;
		}
	}
	// 싱글톤 ---------------





	//public BlockCom[] BlockComArray;// = new BlockCom[0];
	//public Vector2Int MapSize = new Vector2Int(64, 64);
	public int MapSize_Width = 64;
	public int MapSize_Length = 64;
	public int MapSize_Height = 128; // 기본맵 최대높이
	public int OffsetHeight = 50; // 지형생성시 최소높이용

	public Transform MapRootNode = null;


	[Header("[펄린노이즈값]")]
	//public float HeightMulti = 1f;
	public float WaveLength = 1f;
	public float WaveHeight = 1f;

	public float SeedPerlinX = 1f;
	public float SeedPerlinZ = 1f;


	protected Vector3 m_PlayerPos = new Vector3();
	protected List<BlockCom> m_TestRoundBlockList = new List<BlockCom>();
	

	protected bool[,,] m_MapGeneratorFlag;
	protected BlockCom[,,] m_MapBlockArray;


	[ContextMenu("[높이재설정]")]
	protected void Test_SetHeightMap()
	{
		Vector3 temppos;
		foreach( var block in m_TestRoundBlockList )
		{
			temppos = block.transform.position;
			temppos.y = GetPerlinNosiseHeightInt( (int)temppos.x, (int)temppos.z );

			block.transform.position = temppos;
		}

	}



	public BlockCom GetGridIndexBlockCom(int p_x, int p_y, int p_z)
	{
		if( !ISLandoverlap(p_x, p_y, p_z) )
		{
			return null;
		}

		return m_MapBlockArray[p_x, p_y, p_z];
	}
	public BlockCom GetGridIndexBlockCom(Vector3Int p_gridindex)
	{
		if( !ISLandoverlap(p_gridindex.x, p_gridindex.y, p_gridindex.z) )
		{
			return null;
		}

		return m_MapBlockArray[p_gridindex.x, p_gridindex.y, p_gridindex.z];
	}


	protected float GetPerlinNosiseHeightInt( int p_x, int p_z )
	{
		float perlinx = (SeedPerlinX + (float)p_x) / WaveLength;
		float perlinz = (SeedPerlinZ + (float)p_z) / WaveLength;

		float height = Mathf.PerlinNoise( perlinx, perlinz );

		return Mathf.RoundToInt(height * WaveHeight) + OffsetHeight;
	}

	protected void GeneratorMap()
	{
		SeedPerlinX = Random.Range(0f, 100f);
		SeedPerlinZ = Random.Range(0f, 100f);

		int width = MapSize_Width;
		int length = MapSize_Length;

		m_MapGeneratorFlag = new bool[ width, MapSize_Height, length ];
		m_MapBlockArray = new BlockCom[width, MapSize_Height, length];

		// 플레이어 위치설정
		m_PlayerPos.x = (int)(width * 0.5f);
		m_PlayerPos.z = (int)(length * 0.5f);
		m_PlayerPos.y = GetPerlinNosiseHeightInt( (int)m_PlayerPos.x, (int)m_PlayerPos.z ) + 2f;
		GameObject playerobj = GameObject.FindGameObjectWithTag("Player");
		playerobj.transform.position = m_PlayerPos;

		Vector3 temppos = new Vector3();
		for (int xx = 0; xx < width; xx++)
		{
			for (int zz = 0; zz < length; zz++)
			{
				temppos.x = xx; 
				temppos.z = zz;

				temppos.y = GetPerlinNosiseHeightInt( xx, zz );

				E_BlockType blocktype = GetHeightBlockType( (int)temppos.y );
				BlockCom tempblockcom = BlockManager.Instance.GetBlockType( blocktype );// BlockComArray[(int)blocktype];

				CreateBlock( (int)temppos.x, (int)temppos.y, (int)temppos.z, tempblockcom );
				DirectLandUpperFlag( (int)temppos.x, (int)temppos.y, (int)temppos.z );

				GeneratorInterpolateBlock( temppos );
			}
		}

		//GeneratorCave();
	}

	protected void DirectCreateHeightBlock( int p_x, int p_z
		, int p_stheight
		, int p_endheight )
	{
		int tempst = 0;
		int tempend = 0;

		if( p_stheight <= p_endheight )
		{
			tempst = p_stheight + 1;
			tempend = p_endheight - 1;
		}
		else
		{
			tempst = p_endheight + 1;
			tempend = p_stheight - 1;
		}

		for( int i = tempst; i<=tempend; i++ )
		{
			if( ISLandoverlap( p_x, i , p_z ) )
			{
				E_BlockType blocktype = GetHeightBlockType( i );
				BlockCom tempblockcom = BlockManager.Instance.GetBlockType( blocktype );
				CreateBlock( p_x, i, p_z, tempblockcom );
			}
		}
	}

	protected void GeneratorInterpolateBlock( Vector3 p_worldpos )
	{
		Vector3Int temppos = Vector3Int.RoundToInt( p_worldpos );
		int compareheight = temppos.y;

		// 좌
		temppos.y = (int)GetPerlinNosiseHeightInt( temppos.x - 1, temppos.z );
		if( Mathf.Abs(temppos.y - compareheight) >= 2 )
		{
			DirectCreateHeightBlock( temppos.x - 1, temppos.z, compareheight, temppos.y );
		}

		// 좌
		temppos.y = (int)GetPerlinNosiseHeightInt( temppos.x + 1, temppos.z );
		if( Mathf.Abs(temppos.y - compareheight) >= 2 )
		{
			DirectCreateHeightBlock( temppos.x + 1, temppos.z, compareheight, temppos.y );
		}

		// 앞
		temppos.y = (int)GetPerlinNosiseHeightInt( temppos.x, temppos.z + 1 );
		if( Mathf.Abs(temppos.y - compareheight) >= 2 )
		{
			DirectCreateHeightBlock( temppos.x, temppos.z + 1, compareheight, temppos.y );
		}
		// 뒤
		temppos.y = (int)GetPerlinNosiseHeightInt( temppos.x, temppos.z - 1 );
		if( Mathf.Abs(temppos.y - compareheight) >= 2 )
		{
			DirectCreateHeightBlock( temppos.x, temppos.z - 1, compareheight, temppos.y );
		}

	}

	protected E_BlockType GetHeightBlockType( int p_y )
	{
		if( p_y > 70 )
		{
			return E_BlockType.Ice;
		}
		else if( p_y > 60 )
		{
			return E_BlockType.Grass;
		}
		else if( p_y > 50 )
		{
			return E_BlockType.Desert;
		}

		return E_BlockType.Soil;
	}

	protected void DirectLandUpperFlag( int p_x, int p_y, int p_z )
	{
		for( int i= p_y + 1; i<MapSize_Height; ++i )
		{
			m_MapGeneratorFlag[p_x, i, p_z] = true;
		}

	}

	public BlockCom CreateBlock( int p_x, int p_y, int p_z, BlockCom p_blockcom )
	{
		if( m_MapGeneratorFlag[p_x, p_y, p_z] != null )
		{
			Debug.LogFormat( "Fill Block : {0}, {1}, {2}", p_x, p_y, p_z );

		}


		Vector3 temppos = new Vector3(p_x, p_y, p_z);
		BlockCom copyblock = GameObject.Instantiate( p_blockcom
										, temppos
										, Quaternion.identity
										, MapRootNode );

		copyblock.name = string.Format("Block_{0},{1},{1}", p_x, p_y, p_z );

		m_TestRoundBlockList.Add(copyblock);

		m_MapGeneratorFlag[p_x, p_y, p_z] = true;
		m_MapBlockArray[ p_x, p_y, p_z ] = copyblock;

		return copyblock;
	}


	public bool ISAreadyBlock( int p_x, int p_y, int p_z )
	{
		if( !ISLandoverlap(p_x, p_y, p_z) )
		{
			return true;
		}

		return m_MapGeneratorFlag[p_x, p_y, p_z];
	}

	protected bool ISLandoverlap(int p_x, int p_y, int p_z)
	{
		if( p_x < 0 || p_x >= MapSize_Width )
			return false;
		if( p_y < 0 || p_y >= MapSize_Height )
			return false;
		if( p_z < 0 || p_z >= MapSize_Length )
			return false;

		return true;
	}

	protected void DirectCreateBlock( int p_x, int p_y, int p_z )
	{
		// if( !ISLandoverlap(p_x, p_y, p_z) )
		// {
		// 	return;
		// }

		if( !ISAreadyBlock(p_x, p_y, p_z) )
		{
			// 임시용
			BlockCom tempblockcom = BlockManager.Instance.GetBlockType( E_BlockType.Soil );// BlockComArray[0];
			CreateBlock( p_x, p_y, p_z, tempblockcom );
		}
	}

	public void DirectDestryBlock( BlockCom p_blockcom )
	{
		Vector3Int temppos = Vector3Int.RoundToInt( p_blockcom.transform.position );
		GameObject.Destroy( p_blockcom.gameObject );


		m_MapBlockArray[ temppos.x, temppos.y, temppos.z ] = null;
		m_TestRoundBlockList.Remove( p_blockcom );


		// 오른쪽
		DirectCreateBlock( (int)temppos.x + 1, (int)temppos.y, (int)temppos.z );
		// 왼쪽
		DirectCreateBlock( (int)temppos.x - 1, (int)temppos.y, (int)temppos.z );
		// 앞
		DirectCreateBlock( (int)temppos.x, (int)temppos.y, (int)temppos.z + 1 );
		// 뒤
		DirectCreateBlock( (int)temppos.x, (int)temppos.y, (int)temppos.z - 1 );
		// 위
		DirectCreateBlock( (int)temppos.x, (int)temppos.y + 1, (int)temppos.z );
		// 아래
		DirectCreateBlock( (int)temppos.x, (int)temppos.y - 1, (int)temppos.z );
	}


	public BlockCom CreateBlock( Vector3Int p_worldpos, E_BlockType p_blocktype )
	{
		BlockCom tempblockcom = BlockManager.Instance.GetBlockType(p_blocktype);// BlockComArray[(int)p_blocktype];
		return CreateBlock( p_worldpos.x, p_worldpos.y, p_worldpos.z, tempblockcom );
	}


	protected void DirectCaveCreateBlock( int p_x, int p_y, int p_z )
	{
		bool isflag = ISAreadyBlock(p_x, p_y, p_z);
		Debug.LogFormat( "Cave Block Pos : {3},  {0}, {1}, {2} "
			, p_x, p_y, p_z
			, isflag );

		if( !ISAreadyBlock(p_x, p_y, p_z) )
		{
			// 임시용
			BlockCom tempblockcom = BlockManager.Instance.GetBlockType( E_BlockType.Soil );// BlockComArray[0];
			CreateBlock( p_x, p_y, p_z, tempblockcom );

			Debug.LogFormat( "DirectCaveCreateBlock BlockPos IS Flag {3} : {0}, {1}, {2}"
				, p_x, p_y, p_z, m_MapGeneratorFlag[p_x, p_y, p_z] );
		}

	}

	protected void DirectCaveDestryBlock( Vector3Int p_worldpos )
	{

		if( !ISLandoverlap( p_worldpos.x, p_worldpos.y, p_worldpos.z ) )
		{
			return;
		}


		BlockCom tempblockcom = m_MapBlockArray[ p_worldpos.x, p_worldpos.y, p_worldpos.z ];
		if( tempblockcom != null )
		{
			GameObject.Destroy( tempblockcom.gameObject );
			m_TestRoundBlockList.Remove( tempblockcom );
			m_MapBlockArray[ p_worldpos.x, p_worldpos.y, p_worldpos.z ] = null;
		}

		m_MapGeneratorFlag[ p_worldpos.x, p_worldpos.y, p_worldpos.z ] = true;


		// 오른쪽
		DirectCreateBlock( (int)p_worldpos.x + 1, (int)p_worldpos.y, (int)p_worldpos.z );
		// 왼쪽
		DirectCreateBlock( (int)p_worldpos.x - 1, (int)p_worldpos.y, (int)p_worldpos.z );
		// 앞
		DirectCreateBlock( (int)p_worldpos.x, (int)p_worldpos.y, (int)p_worldpos.z + 1 );
		// 뒤
		DirectCreateBlock( (int)p_worldpos.x, (int)p_worldpos.y, (int)p_worldpos.z - 1 );
		// 위
		DirectCreateBlock( (int)p_worldpos.x, (int)p_worldpos.y + 1, (int)p_worldpos.z );
		// 아래
		DirectCreateBlock( (int)p_worldpos.x, (int)p_worldpos.y - 1, (int)p_worldpos.z );
	}

	protected void GeneratorCave()
	{

		for (int i = 0; i < 7; i++)
		{
			Vector3Int randompos = Vector3Int.zero;
			randompos.x = Random.Range(0, MapSize_Width );
			randompos.y = Random.Range(0, OffsetHeight );
			randompos.z = Random.Range(0, MapSize_Length );

			int sizex = 7;
			int sizey = 7;
			int sizez = 7;

			Vector3Int temppos = Vector3Int.zero;
			for (int xx = 0; xx < sizex; xx++)
			{
				for (int yy = 0; yy < sizey; yy++)
				{
					for (int zz = 0; zz < sizez; zz++)
					{
						temppos.x = randompos.x + xx;
						temppos.y = randompos.y + yy;
						temppos.z = randompos.z + zz;
						// Debug.LogFormat( "---Cave Pos : {0}"
						// 	, temppos );
						DirectCaveDestryBlock( temppos );
					}
				}
			}


		}


	}




	void Start () 
	{
		GeneratorMap();
	}
	
	void Update () 
	{
		
	}
}
