﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// https://stackoverflow.com/questions/16377025/base-method-with-multiple-levels-of-inheritance-not-being-called

//using System;
 


public class AA
{
    public virtual void MethodOne()
    {
       Debug.Log( "AA" ); 
    }
}

public class BB : AA
{
    public override void MethodOne()
    {
        base.MethodOne();
        Debug.Log( "BB" );
    }
}

public class CC : BB
{
    public override void MethodOne()
    {
        base.MethodOne();
        Debug.Log( "CC" );
    }
}

 
public class A
{
    public virtual void MethodOne()
    {
       Debug.Log( "A" ); 
    }
}
 
public class B : A
{
    public override void MethodOne()
    {
        base.MethodOne();
        Debug.Log( "B" );
    }
}
 
public class C : B
{
    public override void MethodOne()
    {
        base.MethodOne();
        Debug.Log( "C" );
    }
}


public class testmultiVirtual : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
		var c = new C();
    	c.MethodOne();


        CC cc = new CC();
        cc.MethodOne();
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
