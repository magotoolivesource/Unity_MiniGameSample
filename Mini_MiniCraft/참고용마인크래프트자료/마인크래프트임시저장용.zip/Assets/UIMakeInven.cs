﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIMakeInven : MonoBehaviour 
{
	public UISmithInvenSlot[] InvenSlotArray = new UISmithInvenSlot[9];

	public UISmithInvenSlot ResultSlot = null;

	E_ItemType[,] m_Outdata = new E_ItemType[3,3];
	public E_ItemType[,] GetInvenSlotArrayDatas()
	{
		m_Outdata[2, 0] = InvenSlotArray[0].CurrentItemType;
		m_Outdata[2, 1] = InvenSlotArray[1].CurrentItemType;
		m_Outdata[2, 2] = InvenSlotArray[2].CurrentItemType;

		m_Outdata[1, 0] = InvenSlotArray[3].CurrentItemType;
		m_Outdata[1, 1] = InvenSlotArray[4].CurrentItemType;
		m_Outdata[1, 2] = InvenSlotArray[5].CurrentItemType;

		m_Outdata[0, 0] = InvenSlotArray[6].CurrentItemType;
		m_Outdata[0, 1] = InvenSlotArray[7].CurrentItemType;
		m_Outdata[0, 2] = InvenSlotArray[8].CurrentItemType;

		// for (int i = 0; i < 9; i++)
		// {
		// 	int xx = i % 3;
		// 	int yy = (int)((float)i / 3f);
		// 	m_Outdata[xx, yy] = InvenSlotArray[i].CurrentItemType;
		// }
		
		return m_Outdata;
	}


	protected void AllHideSlots()
	{
		foreach( var element in InvenSlotArray )
		{
			element.SetItemType( E_ItemType.None );
		}

		// 기존인벤에 아이템 넣어주기
	}

	public void _On_MakeBTNClick()
	{
		E_ItemType makeitem = ItemManager.Instance.GetSmithCompareItem( GetInvenSlotArrayDatas() ); 

		Debug.Log("확인용 : " + makeitem.ToString() );
		ResultSlot.SetItemType( makeitem );
		if( makeitem == E_ItemType.None
			|| makeitem == E_ItemType.Max )
		{
			// 실패시
			return;	
		}


		// 새로운 아이템 생성
		if( !(makeitem == E_ItemType.None
			|| makeitem == E_ItemType.Max) )
		{
			// 기존 아이템 삭제
			foreach( var element in InvenSlotArray )
			{
				UserItemManager.Instance.RemoveItem( element.GetItemType(), 1 );
				
			}

			UserItemManager.Instance.AddItem( makeitem, 1 );
			UIManager.Instance.UIItemInvenCom.UIReflashUserItemDatas();
		}


	


		// 성공UI띄우기
		AllHideSlots();


		
		

	}


	
	void Start () 
	{
		
	}
	
	void Update () 
	{
		
	}
}
