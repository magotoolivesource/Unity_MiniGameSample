﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlantBlockCom : MonoBehaviour 
{
	protected E_ItemType m_CurrentItemType = E_ItemType.None;

	public SpriteRenderer[] PlantSpriteRenderArray;

	// 시간에 흐름에 따라서 변하는 스프라이트 갯수
	public Sprite[] PlantSpriteImageArray;

	public float HavertSec = 1f;


	protected bool m_ISHavert = false;

	public void Init( E_ItemType p_itemtype, float p_havertsec = 1f )
	{
		HavertSec = p_havertsec;
		m_CurrentItemType = p_itemtype;
		m_ISHavert = false;

		m_CoroutineCount = PlantSpriteImageArray.Length;
		m_NextSpriteSec = HavertSec / PlantSpriteImageArray.Length;
	}


	void EndEvent()
	{
		int endindex = PlantSpriteImageArray.Length - 1;
		UpdateSprite(endindex);
		m_ISHavert = true;

	}


	void UpdateSprite( int p_spriteindex )
	{
		foreach (var item in PlantSpriteRenderArray)
		{
			item.sprite = PlantSpriteImageArray[p_spriteindex];
		}
	}

	IEnumerator StartPlantProgress()
	{
		for( int i=0; i<m_CoroutineCount; i++ )
		{
			UpdateSprite( i );
			yield return new WaitForSeconds( m_NextSpriteSec );
		}
		

		EndEvent();

		yield break;
	}


	float m_NextSpriteSec = 0f;
	int m_CoroutineCount = 0;
	void Start () 
	{
		StartCoroutine( StartPlantProgress() );
		

	}
	
	void Update () 
	{
		
	}
}
