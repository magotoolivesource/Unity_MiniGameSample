﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockCom : MonoBehaviour 
{
	public E_BlockType CurrentBlockType = E_BlockType.Max;
	public int ResultCount = 1;

	public void SetBlockType( E_BlockType p_blocktype )
	{
		if( CurrentBlockType == p_blocktype )
		{
			return;
		}

		CurrentBlockType = p_blocktype;

		this.GetComponent<MeshRenderer>().material = 
			BlockManager.Instance.GetMaterialBlockType(CurrentBlockType);
	}

	// public void SetBlockEvent()
	// {

	// }


	//FireAttribute m_FireAttributeCom = null;
	public void SetFireEvent()
	{
		Debug.Log("FireEvent : " + this.name );
		if( !(CurrentBlockType == E_BlockType.Grass)
		 )
		{
			return;
		}

		Debug.Log("FireEvent : " + this.name );
		this.gameObject.AddComponent<FireAttribute>();
	}


	public void SetFlantEvent()
	{
		if( !(this.CurrentBlockType == E_BlockType.Grass
			|| this.CurrentBlockType == E_BlockType.Soil ) )
		{
			return;
		}

		this.gameObject.AddComponent<PlantAttribute>();
	}




	void Start () 
	{
		
	}
	
	void Update () 
	{
		
	}
}
