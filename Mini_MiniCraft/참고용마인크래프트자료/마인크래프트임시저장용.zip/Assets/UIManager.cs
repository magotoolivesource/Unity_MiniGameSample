﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class UIManager : Singleton<UIManager> 
{
	public UIMakeInven UIInven = null;
	protected Player MainPlayerCom = null;
	public UIItemDragSlot DragSlotImage = null;
	public UIItemInven UIItemInvenCom = null;
	public UIDockInven UIDockInvenCom = null;


	public bool ISUIOpen
	{
		get;
		protected set;
	}




	public Player MainPlayer
	{
		get{ return MainPlayerCom; }
	}

	public UIItemDragSlot GetDragSlotImage()
	{
		return DragSlotImage;
	}


	void ShowNHideMakeInven()
	{
		UIInven.gameObject.SetActive( !UIInven.gameObject.activeSelf );
		MainPlayerCom.GetPersonController.SetDirectMouseLock( !UIInven.gameObject.activeSelf );
		
		ISUIOpen = UIInven.gameObject.activeSelf;

	}


	void Start () 
	{
		ISUIOpen = false;

		MainPlayerCom = GameObject.FindObjectOfType<Player>();



		UIInven.gameObject.SetActive(false);
		
	}
	
	void Update () 
	{
		if( Input.GetKeyDown(KeyCode.I) )
		{
			ShowNHideMakeInven();
		}

	}


	public void UIReflashAllDatas()
	{
		UIItemInvenCom.UIReflashAllSlots();
		UIDockInvenCom.UIRefrashAllSlotDatas();
		

	}

}
