﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;


// public enum E_PickType
// {
// 	None = 0,
// 	Pickaxe,
// 	BlockFill,
// 	Fire,

// 	Max
// }


public class Player : MonoBehaviour 
{

	public GameObject GuideBlock = null;


	// public E_PickType LeftPickType = E_PickType.None;
	// public E_PickType RightPickType = E_PickType.None;

	public E_ItemType LeftItemEquipType = E_ItemType.None;
	public E_ItemType RightItemEquipType = E_ItemType.None;



	public float m_LeftClickSec = 0f;
	public float m_LeftDelaySec = 1f;
	bool m_ISLeftClick = false;

	public float m_RightClickSec = 0f;
	public float m_RightDelaySec = 1f;
	bool m_ISRightClick = false;


	
	public Camera PlayerCamera;
	public float RayDistance = 4f;


	public E_BlockType FillBlockType = E_BlockType.Max;

	protected FirstPersonController m_PersonController = null;


	public FirstPersonController GetPersonController
	{
		get { return m_PersonController; }
	}

	void Start () 
	{
		GuideBlock.gameObject.SetActive(false);
		m_PersonController = this.GetComponent<FirstPersonController>();
	}
	

	public void SetItemEquipType( E_ItemType p_type, bool p_isleft )
	{
		if(p_isleft)
			LeftItemEquipType = p_type;
		else
			RightItemEquipType = p_type;			
	}
	
	bool ISLeftClickEnable()
	{
		if( Input.GetMouseButton(0)
			&& Time.time > m_LeftClickSec )
		{
			m_ISLeftClick = true;
			return true;
		}

		return false;
	}

	bool ISRightClickEnable()
	{
		if( Input.GetMouseButton(1)
			&& Time.time > m_RightClickSec )
		{
			m_ISRightClick = true;
			return true;
		}

		return false;
	}

	void UpdateClickSetting()
	{
		if( m_ISLeftClick )
		{
			m_LeftClickSec = Time.time + m_LeftDelaySec;
			m_ISLeftClick = false;
		}

		if( m_ISRightClick )
		{
			m_RightClickSec = Time.time + m_RightDelaySec;
			m_ISRightClick = false;
		}
	}



	void SetDigging()
	{
		// float width = (float)Screen.width * 0.5f;
		// float height = (float)Screen.height * 0.5f;
		// Vector3 screenpos = new Vector3( width, height, 0f );

		// Ray rayval = PlayerCamera.ScreenPointToRay( screenpos );
		// RaycastHit hitobj;

		// if( Physics.Raycast(rayval, out hitobj, RayDistance ) )
		// {
		// 	BlockCom blockcom = hitobj.transform.GetComponent<BlockCom>();

		// 	if( blockcom != null )
		// 	{
		// 		//GameObject.Destroy( blockcom.gameObject );
		// 		MapGenerator.GetI.DirectDestryBlock( blockcom );
		// 	}
		// }
		

		BlockCom blockcom = GetScreenPointBlock();
		if( blockcom != null)
		{
			UserItemManager.Instance.DestryBlock( blockcom );
			MapGenerator.GetI.DirectDestryBlock( blockcom );
		}

	}

	BlockCom GetScreenPointBlock()
	{
		float width = (float)Screen.width * 0.5f;
		float height = (float)Screen.height * 0.5f;
		Vector3 screenpos = new Vector3( width, height, 0f );
		Ray rayval = PlayerCamera.ScreenPointToRay( screenpos );

		RaycastHit hitobj;
		if( Physics.Raycast(rayval, out hitobj, RayDistance ) )
		{
			BlockCom blockcom = hitobj.transform.GetComponent<BlockCom>();
			return blockcom;
		}

		return null;
	}
	BlockCom GetScreenPointBlock( out RaycastHit p_hitobj )
	{
		float width = (float)Screen.width * 0.5f;
		float height = (float)Screen.height * 0.5f;
		Vector3 screenpos = new Vector3( width, height, 0f );
		Ray rayval = PlayerCamera.ScreenPointToRay( screenpos );

		if( Physics.Raycast(rayval, out p_hitobj, RayDistance ) )
		{
			BlockCom blockcom = p_hitobj.transform.GetComponent<BlockCom>();
			return blockcom;
		}

		return null;
	}


	void SetFillBlock( E_ItemType p_itemtype )
	{

		RaycastHit hitobj;
		BlockCom blockcom = GetScreenPointBlock( out hitobj );
		if( blockcom != null )
		{
			//hitobj.normal
			Vector3Int temppos = Vector3Int.RoundToInt( blockcom.transform.position );
			temppos += Vector3Int.RoundToInt( hitobj.normal );

			E_BlockType fillblocktype = ItemManager.Instance.GetItemTOBlockType(p_itemtype);
			if(fillblocktype != E_BlockType.Max)
			{
				MapGenerator.GetI.CreateBlock( temppos, fillblocktype );


				UserItemManager.Instance.RemoveItem( p_itemtype, 1);
				UIManager.Instance.UIItemInvenCom.UIReflashAllSlots();
				UIManager.Instance.UIDockInvenCom.UIRefrashAllSlotDatas();
			}

		}


	}

	void SetFire()
	{
		BlockCom blockcom = GetScreenPointBlock();
		if( blockcom != null )
		{
			blockcom.SetFireEvent();
		}
	}

	void SetPickTypeAction( E_ItemType p_type )
	{
		//Debug.LogFormat( " PickType : {0} ", p_type );
		switch (p_type)
		{
			case E_ItemType.None:
			{

			}
			break;
			case E_ItemType.Soil:
			case E_ItemType.Grass:
			case E_ItemType.Desert:
			case E_ItemType.Ice:
			case E_ItemType.Mine:
			case E_ItemType.Iron:
			case E_ItemType.Gold:
			{
				// 채우기
				SetFillBlock( p_type );
			}
			break;
			case E_ItemType.Stone:
			case E_ItemType.Wood:
			{

			}
			break;
			case E_ItemType.StonePick:
			case E_ItemType.IronPick:
			case E_ItemType.IronAxe:
			{
				// 땅파기
				SetDigging();
			}
			break;
			case E_ItemType.Fire:
			{
				SetFire();
			}
			break;
			case E_ItemType.Carrot:
			{
				SetFlant( p_type );
			}
			break;
			default:
			{

			}
			break;
		}


	}


	void SetFlant( E_ItemType p_itemtype )
	{
		BlockCom blockcom = GetScreenPointBlock();
		if( blockcom != null )
		{
			blockcom.SetFlantEvent();


			UserItemManager.Instance.RemoveItem( p_itemtype, 1);
			UIManager.Instance.UIItemInvenCom.UIReflashAllSlots();
			UIManager.Instance.UIDockInvenCom.UIRefrashAllSlotDatas();

			//UserItemManager.Instance.RemoveItem( E_ )
		}
	}

	void FindBlockGuide()
	{
		BlockCom blockcom = GetScreenPointBlock();
		if(blockcom != null)
		{
			GuideBlock.SetActive(true);
			GuideBlock.transform.position = blockcom.transform.position;
		}
		else
		{
			GuideBlock.SetActive(false);
		}

	}

	void Update () 
	{
		FindBlockGuide();

		if( ISLeftClickEnable()
			&& !UIManager.Instance.ISUIOpen )
		{
			SetPickTypeAction( LeftItemEquipType );
		}

		if( ISRightClickEnable()
			&& !UIManager.Instance.ISUIOpen )
		{
			SetPickTypeAction( RightItemEquipType );
		}
		

		// 무조건 마지막임
		UpdateClickSetting();
	}
}
