﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


// 빈슬롯일때 빈슬롯 처리하도록하기
// 아이템 사용시 처리
// 플레어 오른버턴 , 왼버턴 처리하기


public class UIDockInven : MonoBehaviour 
{
	public UIDockSlot[] DockSlotArray;

	public Image LeftDockThum;
	public Image RightDockThum;
	int m_LeftSlotIndex = -1;
	int m_RightSlotIndex = -1;


	void Test_EquipDockInven()
	{
		DockSlotArray[0].SetItemType( E_ItemType.Stone );
		DockSlotArray[5].SetItemType( E_ItemType.Iron );
		DockSlotArray[1].SetItemType( E_ItemType.StonePick );
		DockSlotArray[6].SetItemType( E_ItemType.Carrot );
		
		UpdateLeftDockChange( DockSlotArray[1].CurrentItemType, 1 );
		UpdateRightDockChange( DockSlotArray[5].CurrentItemType, 5 );

	}


	public void UIRefrashAllSlotDatas()
	{
		int count = DockSlotArray.Length;
		for (int i = 0; i < count; i++)
		{
			DockSlotArray[i].UIRefrashData();
			if( m_LeftSlotIndex == i )
			{
				UpdateLeftDockChange( DockSlotArray[i].CurrentItemType , i );
			}

			if( m_RightSlotIndex == i)
			{
				UpdateRightDockChange( DockSlotArray[i].CurrentItemType , i );
			}

		}

	}


	void Start () 
	{
		Test_EquipDockInven();
		UIRefrashAllSlotDatas();
	}

	
	void UpdateLeftDockChange( E_ItemType p_itemtype, int p_index )
	{
		ItemData tempdata = ItemManager.Instance.GetItemData( p_itemtype );
		UserItemData useritemdata = UserItemManager.Instance.GetItemData( p_itemtype );

		if( useritemdata != null )
		{
			LeftDockThum.gameObject.SetActive(true);
			LeftDockThum.sprite = tempdata.ItemSprite;
			m_LeftSlotIndex = p_index;
		}
		else
		{
			LeftDockThum.gameObject.SetActive(false);
			m_LeftSlotIndex = -1;
		}

		UIManager.Instance.MainPlayer.SetItemEquipType( p_itemtype, true );
		
	}

	void UpdateRightDockChange(E_ItemType p_itemtype, int p_index )
	{
		ItemData tempdata = ItemManager.Instance.GetItemData( p_itemtype );
		UserItemData useritemdata = UserItemManager.Instance.GetItemData( p_itemtype );

		if( useritemdata != null )
		{
			RightDockThum.gameObject.SetActive(true);
			RightDockThum.sprite = tempdata.ItemSprite;
			m_RightSlotIndex = p_index;
		}
		else
		{
			RightDockThum.gameObject.SetActive(false);
			m_RightSlotIndex = -1;
		}

		UIManager.Instance.MainPlayer.SetItemEquipType( p_itemtype, false );
	}

	void Update () 
	{

		E_ItemType tempitemtype = E_ItemType.Max;
		bool isleftdock = true;
		bool isclick = false;
		int selectindex = -1;

		// int count = KeyCode.Alpha9 - KeyCode.Alpha1;
		// for(int i= 0; i<count; i++)
		// {
		// 	if( Input.GetKeyDown( KeyCode.Alpha1 + i ) )
		// 	{
		// 		tempitemtype = DockSlotArray[i].CurrentItemType;
		// 		isleftdock = true;
		//
		// 		if( i >= 5 )
		// 		{
		// 			isleftdock = false;
		// 		}
		// 	}
		// }

		if( Input.GetKeyDown( KeyCode.Alpha1 ) )
		{
			tempitemtype = DockSlotArray[0].CurrentItemType;
			isleftdock = true;
			isclick = true;
			selectindex = 0;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha2 ) )
		{
			tempitemtype = DockSlotArray[1].CurrentItemType;
			isleftdock = true;
			isclick = true;
			selectindex = 1;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha3 ) )
		{
			tempitemtype = DockSlotArray[2].CurrentItemType;
			isleftdock = true;
			isclick = true;
			selectindex = 2;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha4 ) )
		{
			tempitemtype = DockSlotArray[3].CurrentItemType;
			isleftdock = true;
			isclick = true;
			selectindex = 3;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha5 ) )
		{
			tempitemtype = DockSlotArray[4].CurrentItemType;
			isleftdock = true;
			isclick = true;
			selectindex = 4;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha6 ) )
		{
			tempitemtype = DockSlotArray[5].CurrentItemType;
			isleftdock = false;
			isclick = true;
			selectindex = 5;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha7 ) )
		{
			tempitemtype = DockSlotArray[6].CurrentItemType;
			isleftdock = false;
			isclick = true;
			selectindex = 6;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha8 ) )
		{
			tempitemtype = DockSlotArray[7].CurrentItemType;
			isleftdock = false;
			isclick = true;
			selectindex = 7;
		}
		else if( Input.GetKeyDown( KeyCode.Alpha9 ) )
		{
			tempitemtype = DockSlotArray[8].CurrentItemType;
			isleftdock = false;
			isclick = true;
			selectindex = 8;
		}


		if( isclick )
		{
			if( isleftdock )
			{
				UpdateLeftDockChange( tempitemtype, selectindex );
			}
			else
			{
				UpdateRightDockChange( tempitemtype, selectindex );
			}

		}
			


	}
}
