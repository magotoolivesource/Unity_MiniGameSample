﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlantAttribute : BaseBlockAttribute 
{

	BlockCom m_LinkBlockCom = null;
	E_ItemType m_PlantItemType = E_ItemType.Max;
	public void SetInitPlantAttribute( E_ItemType p_type )
	{
		m_PlantItemType = p_type;
	}

	void Awake()
	{
		m_LinkBlockCom = this.GetComponent<BlockCom>();

	}
	
	void StartEvent()
	{
		Vector3Int temppos = Vector3Int.RoundToInt( m_LinkBlockCom.transform.position );
		temppos.y += 1;
		BlockCom upblock = MapGenerator.GetI.GetGridIndexBlockCom( temppos );

		if( upblock != null )
		{
			// this.Invoke( "StartEvent", 0.5f );
			// return;
		}
		else
		{
			m_PlantItemType = E_ItemType.Carrot;

			E_BlockType currblocktype = ItemManager.Instance.GetItemTOBlockType( m_PlantItemType );
			BlockCom copyblock = MapGenerator.GetI.CreateBlock(temppos, currblocktype );

			if( copyblock != null )
			{
				PlantBlockCom plantcom = copyblock.GetComponent<PlantBlockCom>();
				plantcom.Init( m_PlantItemType, 2f );

				
			}


			// BlockCom copyblock = 
			// if( copyblock != null )
			// {
			// 	PlantBlockCom plantcom = copyblock.GetComponent<PlantBlockCom>();
			// 	plantcom.Init( m_PlantItemType, 2f );
			// }

		}



		EndEvent();
	}

	void EndEvent()
	{

		// 현재 등록된 컴포넌트 지우기
		GameObject.Destroy( this );
	}

	void Start () 
	{
		this.Invoke( "StartEvent", 0.5f );
	}
	
	void Update () 
	{
		
	}
}
