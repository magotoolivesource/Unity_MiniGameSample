﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;


public class UIDockSlot : MonoBehaviour
, IBaseSlot
, IDropHandler
, IBeginDragHandler
, IDragHandler
, IPointerUpHandler
{

	public E_ItemType CurrentItemType = E_ItemType.Max;
	public Image CurrentImage = null;
	public Text CountLabel = null;
	public Image CountBGImage = null;



	public E_ItemType GetItemType()
	{
		return CurrentItemType;
	}
	public E_SlotType SlotType
	{
		get { return E_SlotType.E_DockSlot; }
	}

	public void OnDrag(PointerEventData eventData)
	{
		//Debug.Log("Smith OnDrag : " + this.name );
		if( m_DragSlotImage != null )
		{
			//RectTransformUtility.CalculateRelativeRectTransformBounds()
			m_DragSlotImage.GetComponent<RectTransform>().anchoredPosition = eventData.position;
		}
	}

	
	UIItemDragSlot m_DragSlotImage = null;
	public void OnBeginDrag(PointerEventData eventData)
	{
		//Debug.Log("Smith BeginDrag : " + this.name );

		if( this.CurrentItemType == E_ItemType.Max
			|| this.CurrentItemType == E_ItemType.None )
		{
			return;
		}

		m_DragSlotImage = UIManager.Instance.GetDragSlotImage();
		m_DragSlotImage.gameObject.SetActive(true);
		m_DragSlotImage.SetChangeSlotIcon( CurrentImage.sprite );
		
	}

	public void OnPointerUp(PointerEventData eventData)
	{
		if( m_DragSlotImage != null)
		{
			m_DragSlotImage.gameObject.SetActive(false);
			m_DragSlotImage = null;
		}
	}

	public void OnDrop(PointerEventData eventData)
	{
		PointerEventData pointerevent = eventData;// p_pointevent as PointerEventData;

		Debug.Log( this.name + " : Drop : " + pointerevent.pointerPress.name );


		E_ItemType srctype = CurrentItemType;
		IBaseSlot destslot = 
					pointerevent.pointerPress.GetComponent<IBaseSlot>();
		E_ItemType desttype = destslot.GetItemType();


		if(destslot.SlotType == E_SlotType.E_InvenSlot )
		{
			this.SetItemType( desttype );
		}
		else
		{
			// swap
			destslot.SetItemType( srctype );
			this.SetItemType( desttype );
		}
		


		if( m_DragSlotImage != null)
		{
			m_DragSlotImage.gameObject.SetActive(false);
			m_DragSlotImage = null;
		}
	}


	public void SetItemType( E_ItemType p_itemtype )
	{
		if( CurrentImage == null )
		{
			CurrentImage = this.GetComponent<Image>();
		}

		CurrentItemType = p_itemtype;

		ItemData data = ItemManager.Instance.GetItemData( CurrentItemType );

		if( data != null
		 && data.ItemType != E_ItemType.None
		 && data.ItemType != E_ItemType.Max
		  )
		{
			CurrentImage.sprite = data.ItemSprite;
			CurrentImage.color = new Color(1f, 1f, 1f, 1f );
		}
		else
		{
			CurrentImage.sprite = null;
			CurrentImage.color = new Color(1f, 1f, 1f, 0f );
		}
		
		UIRefrashData();
	}

	
	public void UIRefrashData()
	{
		UserItemData itemdata = UserItemManager.Instance.GetItemData( CurrentItemType );


		if( itemdata == null )
		{
			CurrentItemType = E_ItemType.None;
			CurrentImage.color = new Color(1f, 1f, 1f, 0f );

			CountLabel.gameObject.SetActive(false);
			CountBGImage.gameObject.SetActive(false);
		}
		else
		{
			CurrentImage.color = new Color(1f, 1f, 1f, 1f );

			CountLabel.text = itemdata.TotalCount.ToString();
			CountLabel.gameObject.SetActive(true);
			CountBGImage.gameObject.SetActive(true);
			
		}


	}

	void Start () 
	{
		//SetItemType( CurrentItemType );
	}
	
	void Update () 
	{
		
	}



}
