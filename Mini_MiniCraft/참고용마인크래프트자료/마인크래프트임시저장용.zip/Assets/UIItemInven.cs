﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIItemInven : MonoBehaviour 
{
	public List<UIItemInvenSlot> AllItemInvenSlot = new List<UIItemInvenSlot>();


	[ContextMenu("[AdjustInvenSlot]")]
	void Editor_ChildItemInvenSlot()
	{
		AllItemInvenSlot.Clear();

		UIItemInvenSlot[] allslot = this.GetComponentsInChildren<UIItemInvenSlot>();
		AllItemInvenSlot.AddRange( allslot );

	}


	public void UIReflashAllSlots()
	{
		foreach (var item in AllItemInvenSlot)
		{
			item.UpdateItemData();
		}

	}

	public void UIAddEmptySlot( E_ItemType p_itemtype )
	{
		foreach (var item in AllItemInvenSlot)
		{
			if( item.CurrentItemType == E_ItemType.None
			|| item.CurrentItemType == E_ItemType.Max )
			{
				item.SetItemType( p_itemtype );
				return;
			}
		}
	}

	public void UIReflashUserItemDatas()
	{
		List<UserItemData> allitemdatalist = UserItemManager.Instance.TotalItemData;


		int totalcount = allitemdatalist.Count;
		UserItemData tempdata = null;
		for (int i = 0; i < totalcount; i++)
		{
			tempdata = allitemdatalist[i];
			AllItemInvenSlot[i].SetItemType( tempdata.CurrentItemType );
		}


		// 나머지 초기화
		int slotcount = AllItemInvenSlot.Count;
		for (int i = totalcount; i < slotcount; i++)
		{
			AllItemInvenSlot[i].SetItemType( E_ItemType.None );
		}

	}

	void Start () 
	{
		UIReflashUserItemDatas();





		
	}
	
	void Update () 
	{
		
	}
}
