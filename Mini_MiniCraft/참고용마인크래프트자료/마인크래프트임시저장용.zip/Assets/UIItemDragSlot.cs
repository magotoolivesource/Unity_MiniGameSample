﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIItemDragSlot : MonoBehaviour 
{
	Image m_Image = null;

	public void SetChangeSlotIcon( Sprite p_icon )
	{
		if( m_Image == null )
		{
			m_Image = this.GetComponent<Image>();
		}

		if( p_icon == null )
		{
			m_Image.sprite = null;
			m_Image.color = new Color( 0, 0, 0, 0);// Color.clear;
		}
		else
		{
			this.GetComponent<Image>().sprite = p_icon;
			m_Image.color = Color.white;
		}
		


	}



	void Start () 
	{
		
	}
	
	void Update () 
	{
		
	}
}
