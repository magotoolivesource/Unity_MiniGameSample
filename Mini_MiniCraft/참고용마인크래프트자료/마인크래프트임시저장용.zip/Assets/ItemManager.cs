﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



// public enum E_BlockType
// {
// 	Soil = 0,
// 	Grass,
// 	Desert,
// 	Ice,

// 	Mine,
// 	Iron,
// 	Gold,

// 	Max
// }

public enum E_ItemType
{
	None = 0,
	// blocktype
	Soil,
	Grass,
	Desert,
	Ice,
	Mine,
	Iron,
	Gold,
	Carrot,
	// blocktype

	Stone,
	Wood,

	StonePick, // 
	IronPick,
	IronAxe,
	Scythe,

	Fire,

	


	Max
}


[System.Serializable]
public class ItemData
{
	public E_ItemType ItemType = E_ItemType.Max;
	public Sprite ItemSprite = null;

	//public string ItemName = "";
	//public string Descript = "";

}

[System.Serializable]
public class SmithItemType
{
	public E_ItemType ResultItemType = E_ItemType.Max;
	public E_ItemType[,] CompareArray = new E_ItemType[3, 3];
}



public class ItemManager : Singleton<ItemManager>
{
	public List<SmithItemType> AllSmithItemType = new List<SmithItemType>();



	public List<ItemData> AllItemDataList = new List<ItemData>();
	// {
	// 	new ItemData(){ ItemType = E_ItemType.None, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.Stone, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.Wood, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.Iron, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.StonePick, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.IronPick, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.IronAxe, ItemSprite = null }
	// 	, new ItemData(){ ItemType = E_ItemType.Scythe, ItemSprite = null }
	// };



	public E_ItemType GetBlockTypeTOItem( E_BlockType p_blocktype )
	{
		E_ItemType outtype = E_ItemType.None;

		if( p_blocktype == E_BlockType.Max )
		{
			return outtype;
		}


		outtype = (E_ItemType)( (int)p_blocktype + 1 );
		return outtype;
	}

	public E_BlockType GetItemTOBlockType(E_ItemType p_itemtype)
	{
		E_BlockType outtype = E_BlockType.Max;

		if( E_ItemType.Soil <= p_itemtype && p_itemtype <= E_ItemType.Carrot )
		{
			outtype = (E_BlockType)((int)p_itemtype - 1);
		}
		else
		{
			Debug.LogError("BlockType Over : " + p_itemtype.ToString() );
		}

		return outtype;
	}


	[ContextMenu("[아이템데이터정리]")]
	void Editor_AdjustAllItemData()
	{
		List<ItemData> TempItemDataList = new List<ItemData>
		{
			new ItemData(){ ItemType = E_ItemType.None, ItemSprite = null }

			, new ItemData(){ ItemType = E_ItemType.Soil, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Grass, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Desert, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Ice, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Mine, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Iron, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Gold, ItemSprite = null }

			, new ItemData(){ ItemType = E_ItemType.Stone, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Wood, ItemSprite = null }

			, new ItemData(){ ItemType = E_ItemType.StonePick, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.IronPick, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.IronAxe, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Scythe, ItemSprite = null }

			, new ItemData(){ ItemType = E_ItemType.Fire, ItemSprite = null }
			, new ItemData(){ ItemType = E_ItemType.Carrot, ItemSprite = null }
		};

		int count = TempItemDataList.Count;
		int tempcount = AllItemDataList.Count;
		if( count > tempcount )
		{
			for( int i=tempcount; i<count; i++)
			{
				AllItemDataList.Add( new ItemData() );
			}
		}
		else if (count < tempcount)
		{
			AllItemDataList.RemoveRange(count, tempcount);
		}
		

		for( int i= 0; i<count; i++ )
		{
			AllItemDataList[i].ItemType = TempItemDataList[i].ItemType;
		}



	}





	//public Dictionary<E_ItemType, ItemData> m_AllItemDataDic = new Dictionary<E_ItemType, ItemData>();
	public ItemData GetItemData( E_ItemType p_itemtype )
	{
		//return m_AllItemDataDic[p_itemtype];
		foreach( var itemdata in AllItemDataList )
		{
			if( itemdata.ItemType == p_itemtype )
			{
				return itemdata;
			}
		}

		return null;
	}

	public E_ItemType GetSmithCompareItem( E_ItemType[,] p_arraydata )
	{
		bool isflag = false;
		// 아이템들비교
		foreach( var smithitem in AllSmithItemType )
		{
			isflag = false;

			// 개별비교
			for (int yy = 0; yy < 3; yy++)
			{
				for (int xx = 0; xx < 3; xx++)
				{
					// if( (smithitem.CompareArray[xx, yy] == E_ItemType.Max
					// || smithitem.CompareArray[xx, yy] == E_ItemType.None)
					// && (p_arraydata[xx, yy] == E_ItemType.Max
					// || p_arraydata[xx, yy] == E_ItemType.None ) )
					// {

					// }
					if( smithitem.CompareArray[yy, xx] != p_arraydata[yy, xx] )
					{
						isflag = true;
					}

					if(isflag) break;
				}

				if(isflag) break;
			}
			
			if( !isflag )
			{
				return smithitem.ResultItemType;
			}
		}

		return E_ItemType.None;
	}



	void Awake()
	{
		// StonePick
		SmithItemType itemtype = new SmithItemType();
		itemtype.ResultItemType = E_ItemType.StonePick;
		itemtype.CompareArray = new E_ItemType[3, 3]
		{
			{E_ItemType.Stone, E_ItemType.Stone, E_ItemType.Stone},
			{E_ItemType.None, E_ItemType.Wood, E_ItemType.None},
			{E_ItemType.None, E_ItemType.Wood, E_ItemType.None}
		};
		AllSmithItemType.Add( itemtype );


		// IronAxe
		itemtype = new SmithItemType();
		itemtype.ResultItemType = E_ItemType.IronAxe;
		itemtype.CompareArray = new E_ItemType[3, 3]
		{
			{E_ItemType.None, E_ItemType.Iron, E_ItemType.Iron},
			{E_ItemType.None, E_ItemType.Wood, E_ItemType.None},
			{E_ItemType.None, E_ItemType.Wood, E_ItemType.None}
		};
		AllSmithItemType.Add( itemtype );


		TestSmithItem();
	}

	void TestSmithItem()
	{
		SmithItemType itemtype = new SmithItemType();
		itemtype.ResultItemType = E_ItemType.StonePick;
		itemtype.CompareArray = new E_ItemType[3, 3]
		{
			{E_ItemType.None, E_ItemType.Iron, E_ItemType.Iron},
			{E_ItemType.None, E_ItemType.Wood, E_ItemType.None},
			{E_ItemType.None, E_ItemType.Wood, E_ItemType.None}
		};
		
		E_ItemType resulttype = GetSmithCompareItem( itemtype.CompareArray );
		Debug.Log("ResultType : " + resulttype.ToString() );



	}


	void Start () 
	{
		
	}
	
	void Update () 
	{
		
	}
}
